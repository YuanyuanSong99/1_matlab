function [ Cp_ave_area,Cg_ave_area,Cgp_ave_area ] = C_ave_area( Cp,Cg,Cgp,nx_a,nx_b,ny_a,ny_b )
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
Cp_ave_area(1:131,1:39)=0;
Cg_ave_area(1:131,1:39)=0;
Cgp_ave_area(1:131,1:39)=0;

for iyear=1:39
    for iday=1:131
        Cp_ave_area(iday,iyear)=mean(mean(Cp(nx_a:nx_b,ny_a:ny_b,iday,iyear)));
        Cg_ave_area(iday,iyear)=mean(mean(Cg(nx_a:nx_b,ny_a:ny_b,iday,iyear)));
        Cgp_ave_area(iday,iyear)=mean(mean(Cgp(nx_a:nx_b,ny_a:ny_b,iday,iyear)));
    end
end


end

